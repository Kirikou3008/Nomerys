# Nomerys custom form

Fichiers :
- `start.html`
- `start.css`
- `start.js`

À mettre dans le dépôt GitHub Pages de Nomerys.

URL finale probable :
- `https://nomerys.com/start.html`

Le formulaire envoie vers :
`https://baptistepaixao2.app.n8n.cloud/webhook/voyage-form`

Important :
n8n doit répondre au POST avec un JSON comme :
```json
{
  "checkout_url": "https://checkout.stripe.com/..."
}
```

Sinon le formulaire sera bien envoyé, mais le client ne sera pas redirigé vers Stripe.

Champs conservés :
- q3_nom.first
- q3_nom.last
- q4_email
- q36_avezvousDeja
- q54_nombreDe
- q65_ageDe
- q37_q_arrive_city
- q38_q_date_start
- q39_q_date_end
- q53_lieuPrecis
- q41_q_climate
- q47_q_regions
- q48_q_style
- q56_typeDe
- q51_activitesA51
- q64_already_paid
