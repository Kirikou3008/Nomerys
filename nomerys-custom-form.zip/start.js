// ===============================
// NOMERYS CUSTOM FORM
// GitHub Pages front-end only.
// Stripe must be created securely in n8n.
// ===============================

const WEBHOOK_URL = "https://baptistepaixao2.app.n8n.cloud/webhook/voyage-form";

// IMPORTANT : n8n devra répondre avec { "checkout_url": "https://checkout.stripe.com/..." }
// Si tu préfères créer un nouveau webhook spécial paiement, remplace WEBHOOK_URL ci-dessus.

const state = {
  step: 0,
  data: {
    q64_already_paid: "",
    selected_plan: "integral_1eur"
  }
};

const stepsRoot = document.getElementById("steps");
const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");
const alertBox = document.getElementById("alertBox");
const alertMessage = document.getElementById("alertMessage");

const steps = [
  {
    id: "intro",
    title: "Prêt à trouver ton voyage ?",
    desc: "Ça prend environ 2 minutes. On te pose uniquement les questions utiles.",
    render: () => `
      <div class="choice-grid">
        ${choice("Oui, commencer", "start", "Je réponds au formulaire maintenant")}
        ${choice("J’ai déjà payé", "alreadyPaid", "Je corrige une ancienne demande")}
      </div>
    `,
    validate: () => {
      if (state.data.introChoice === "alreadyPaid") state.data.q64_already_paid = "true";
      return !!state.data.introChoice || "Choisis une option pour continuer.";
    }
  },
  {
    id: "identity",
    title: "On commence par toi.",
    desc: "Ces infos servent à t’envoyer ton résultat.",
    render: () => `
      <div class="grid-2">
        ${field("Prénom", "firstName", "text", "Baptiste")}
        ${field("Nom", "lastName", "text", "Paixao")}
      </div>
      ${field("Email", "q4_email", "email", "ton@email.com")}
    `,
    validate: () => {
      const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value("q4_email"));
      if (!value("firstName") || !value("lastName")) return "Entre ton prénom et ton nom.";
      if (!emailOk) return "Entre une adresse email valide.";
      return true;
    }
  },
  {
    id: "known",
    title: "Tu sais déjà où tu veux partir ?",
    desc: "On adapte les questions selon ta réponse.",
    render: () => `
      <div class="choice-grid">
        ${choice("Oui j'ai déjà une destination", "Oui j'ai déjà une destination", "Je sais déjà où aller")}
        ${choice("Non je n'ai pas d'idée", "Non je n'ai pas d'idée", "Je veux qu’on m’aide à choisir")}
      </div>
    `,
    validate: () => !!state.data.q36_avezvousDeja || "Choisis une réponse."
  },
  {
    id: "destination",
    title: "Destination.",
    desc: "Indique l’endroit précis si tu l’as déjà, sinon donne tes préférences.",
    condition: () => true,
    render: () => {
      if (state.data.q36_avezvousDeja === "Oui j'ai déjà une destination") {
        return `
          ${field("Ville/zone d’arrivée", "q37_q_arrive_city", "text", "Tokyo, Phuket, Hanoï...")}
          ${field("Lieu précis que vous aimeriez visiter", "q53_lieuPrecis", "text", "Shibuya, Osaka, plage précise...")}
        `;
      }
      return `
        ${field("Ville/zone d’arrivée", "q37_q_arrive_city", "text", "Laisse vide si tu n’as aucune idée")}
        ${multiChoice("Type de destination souhaité", "q56_typeDe", [
          ["Plage", "Soleil, mer, repos"],
          ["Ville", "Découverte, restaurants, quartiers"],
          ["Nature", "Paysages, randonnées, calme"],
          ["Mix", "Un peu de tout"]
        ])}
        ${multiChoice("Région(s) préférée(s)", "q47_q_regions", [
          ["Europe", "Proche et pratique"],
          ["Asie", "Dépaysement fort"],
          ["Amérique", "Grand voyage"],
          ["Peu importe", "Je suis ouvert"]
        ])}
      `;
    },
    validate: () => {
      if (state.data.q36_avezvousDeja === "Oui j'ai déjà une destination" && !value("q37_q_arrive_city")) {
        return "Indique au moins une ville ou zone d’arrivée.";
      }
      return true;
    }
  },
  {
    id: "dates",
    title: "Tes dates.",
    desc: "Les dates doivent être cohérentes pour éviter les erreurs.",
    render: () => `
      <div class="grid-2">
        ${field("Date de départ", "startDateRaw", "date")}
        ${field("Date de retour", "endDateRaw", "date")}
      </div>
    `,
    validate: () => {
      const s = value("startDateRaw");
      const e = value("endDateRaw");
      if (!s || !e) return "Sélectionne une date de départ et une date de retour.";
      const start = new Date(s);
      const end = new Date(e);
      if (end <= start) return "La date de retour doit être après la date de départ.";
      const days = Math.round((end - start) / (1000 * 60 * 60 * 24));
      if (days > 45) return "Les dates semblent trop espacées. Mets un séjour plus court ou contacte-nous.";
      return true;
    }
  },
  {
    id: "travellers",
    title: "Qui voyage ?",
    desc: "Indique le nombre de voyageurs et leur âge.",
    render: () => `
      ${field("Nombre de voyageurs", "q54_nombreDe", "number", "1", "1", "10")}
      <div class="field">
        <label>Âge des voyageurs</label>
        <div class="age-list" id="ageList"></div>
      </div>
    `,
    afterRender: () => {
      buildAgeInputs();
      document.querySelector("[name='q54_nombreDe']").addEventListener("input", buildAgeInputs);
    },
    validate: () => {
      const n = parseInt(value("q54_nombreDe"), 10);
      if (!n || n < 1) return "Indique au moins 1 voyageur.";
      if (n > 10) return "Pour l’instant, Nomerys accepte maximum 10 voyageurs.";
      const ages = [...document.querySelectorAll(".age-input")].map(i => i.value.trim()).filter(Boolean);
      if (ages.length !== n) return "Il faut exactement un âge par voyageur.";
      if (ages.some(a => Number(a) < 0 || Number(a) > 120)) return "Un âge semble incorrect.";
      state.data.q65_ageDe = JSON.stringify(ages.map(a => ({ "Âge": String(a) })));
      return true;
    }
  },
  {
    id: "style",
    title: "Ton style de voyage.",
    desc: "Aide-nous à comprendre l’ambiance que tu veux.",
    render: () => `
      ${multiChoice("Climat souhaité", "q41_q_climate", [
        ["Chaud", "Soleil et chaleur"],
        ["Doux", "Tempéré, agréable"],
        ["Froid", "Hiver, neige, ambiance cozy"],
        ["Peu importe", "Je suis flexible"]
      ])}
      ${multiChoice("Ambiance de voyage", "q48_q_style", [
        ["Relax", "Repos, calme"],
        ["Aventure", "Découverte, adrénaline"],
        ["Culture", "Musées, monuments, histoire"],
        ["Luxe simple", "Beau, propre, confortable"]
      ])}
    `,
    validate: () => true
  },
  {
    id: "activities",
    title: "Ce que tu veux faire.",
    desc: "Optionnel, mais ça aide à rendre la proposition plus pertinente.",
    render: () => `
      ${textarea("Activités à faire", "q51_activitesA51", "Ex : restaurants locaux, musées, plage, shopping, quartiers animés...")}
    `,
    validate: () => true
  },
  {
    id: "plan",
    title: "Choisis ton plan.",
    desc: "Offre de lancement actuelle.",
    render: () => `
      <div class="plan-card">
        <strong>Plan intégral</strong>
        <div class="price">1€</div>
        <div class="check">✓ Vols & hébergements</div>
        <div class="check">✓ Activités et conseils essentiels</div>
        <div class="check">✓ Résultat envoyé par email</div>
      </div>
    `,
    validate: () => true
  },
  {
    id: "summary",
    title: "Dernière vérification.",
    desc: "Si tout est bon, tu seras redirigé vers le paiement sécurisé.",
    render: () => `
      <div class="preview-card">
        <div class="preview-line"><span>Email</span><strong>${escapeHtml(value("q4_email") || "—")}</strong></div>
        <div class="preview-line"><span>Destination</span><strong>${escapeHtml(value("q37_q_arrive_city") || "À définir")}</strong></div>
        <div class="preview-line"><span>Dates</span><strong>${escapeHtml(formatRange())}</strong></div>
        <div class="preview-line"><span>Voyageurs</span><strong>${escapeHtml(value("q54_nombreDe") || "—")}</strong></div>
      </div>
    `,
    validate: () => true,
    submit: true
  }
];

function choice(title, val, sub) {
  return `<div class="choice" data-choice="${escapeAttr(val)}">
    <strong>${title}</strong><small>${sub || ""}</small>
  </div>`;
}

function field(label, name, type, placeholder="", min="", max="") {
  return `<div class="field">
    <label>${label}</label>
    <input type="${type}" name="${name}" placeholder="${placeholder || ""}" value="${escapeAttr(state.data[name] || "")}" ${min ? `min="${min}"` : ""} ${max ? `max="${max}"` : ""}/>
  </div>`;
}

function textarea(label, name, placeholder="") {
  return `<div class="field">
    <label>${label}</label>
    <textarea name="${name}" placeholder="${placeholder}">${escapeHtml(state.data[name] || "")}</textarea>
  </div>`;
}

function multiChoice(label, name, items) {
  return `<div class="field">
    <label>${label}</label>
    <div class="choice-grid" data-multi="${name}">
      ${items.map(([t,s]) => `<div class="choice ${state.data[name] === t ? "selected" : ""}" data-multi-choice="${escapeAttr(t)}"><strong>${t}</strong><small>${s}</small></div>`).join("")}
    </div>
  </div>`;
}

function render() {
  const step = steps[state.step];
  stepsRoot.innerHTML = `<div class="step active"><h2>${step.title}</h2><p>${step.desc}</p>${step.render()}</div>`;
  if (step.afterRender) step.afterRender();
  bindInputs();
  updateUI();
  updatePreview();
}

function bindInputs() {
  document.querySelectorAll("input,textarea,select").forEach(el => {
    el.addEventListener("input", () => {
      state.data[el.name] = el.value;
      updatePreview();
    });
  });

  document.querySelectorAll("[data-choice]").forEach(el => {
    el.addEventListener("click", () => {
      const val = el.dataset.choice;
      if (val === "start" || val === "alreadyPaid") state.data.introChoice = val;
      else state.data.q36_avezvousDeja = val;
      document.querySelectorAll("[data-choice]").forEach(c => c.classList.remove("selected"));
      el.classList.add("selected");
    });
  });

  document.querySelectorAll("[data-multi]").forEach(group => {
    group.querySelectorAll("[data-multi-choice]").forEach(el => {
      el.addEventListener("click", () => {
        const name = group.dataset.multi;
        state.data[name] = el.dataset.multiChoice;
        group.querySelectorAll(".choice").forEach(c => c.classList.remove("selected"));
        el.classList.add("selected");
      });
    });
  });
}

function buildAgeInputs() {
  const n = Math.min(Math.max(parseInt(value("q54_nombreDe") || "1", 10), 1), 10);
  const ageList = document.getElementById("ageList");
  if (!ageList) return;
  const current = [...document.querySelectorAll(".age-input")].map(i => i.value);
  ageList.innerHTML = Array.from({ length: n }, (_, i) => `
    <div class="age-row">
      <span>Voyageur ${i + 1}</span>
      <input class="age-input" type="number" min="0" max="120" placeholder="Âge" value="${escapeAttr(current[i] || "")}">
    </div>
  `).join("");
}

function value(name) {
  const el = document.querySelector(`[name="${CSS.escape(name)}"]`);
  if (el) return el.value.trim();
  return (state.data[name] || "").toString().trim();
}

function collectVisibleInputs() {
  document.querySelectorAll("input,textarea,select").forEach(el => {
    state.data[el.name] = el.value;
  });
}

function validateCurrent() {
  collectVisibleInputs();
  const result = steps[state.step].validate();
  if (result === true) {
    hideAlert();
    return true;
  }
  showAlert(result);
  return false;
}

function next() {
  if (!validateCurrent()) return;
  if (steps[state.step].submit) return submitForm();

  state.step++;
  render();
}

function prev() {
  if (state.step > 0) {
    state.step--;
    render();
  }
}

function updateUI() {
  const pct = Math.round((state.step / (steps.length - 1)) * 100);
  document.getElementById("stepText").textContent = `Étape ${state.step + 1} / ${steps.length}`;
  document.getElementById("progressPercent").textContent = `${pct}%`;
  document.getElementById("progressFill").style.width = `${pct}%`;
  prevBtn.disabled = state.step === 0;
  nextBtn.textContent = steps[state.step].submit ? "Continuer vers le paiement →" : "Suivant →";
}

function updatePreview() {
  document.getElementById("previewDestination").textContent = value("q37_q_arrive_city") || "À définir";
  document.getElementById("previewDates").textContent = formatRange();
  document.getElementById("previewTravellers").textContent = value("q54_nombreDe") ? `${value("q54_nombreDe")} personne(s)` : "—";
}

function formatRange() {
  const s = value("startDateRaw");
  const e = value("endDateRaw");
  if (!s || !e) return "—";
  return `${s} → ${e}`;
}

function dateObj(raw) {
  const [year, month, day] = raw.split("-");
  return { day, month, year };
}

function buildPayload() {
  const start = dateObj(state.data.startDateRaw);
  const end = dateObj(state.data.endDateRaw);

  return {
    // Champs Jotform exacts conservés pour n8n
    q3_nom: {
      first: state.data.firstName || "",
      last: state.data.lastName || ""
    },
    q4_email: state.data.q4_email || "",
    q36_avezvousDeja: state.data.q36_avezvousDeja || "",
    q54_nombreDe: state.data.q54_nombreDe || "",
    q65_ageDe: state.data.q65_ageDe || "",
    q37_q_arrive_city: state.data.q37_q_arrive_city || "",
    q38_q_date_start: start,
    q39_q_date_end: end,
    q53_lieuPrecis: state.data.q53_lieuPrecis || "",
    q41_q_climate: state.data.q41_q_climate || "",
    q47_q_regions: state.data.q47_q_regions || "",
    q48_q_style: state.data.q48_q_style || "",
    q56_typeDe: state.data.q56_typeDe || "",
    q51_activitesA51: state.data.q51_activitesA51 || "",
    q64_already_paid: state.data.q64_already_paid || "",

    // Infos custom utiles
    selected_plan: "integral_1eur",
    source: "nomerys_custom_form",
    submitSource: "custom_form",
    submitDate: new Date().toISOString()
  };
}

async function submitForm() {
  if (!validateCurrent()) return;

  showLoading();

  try {
    const res = await fetch(WEBHOOK_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(buildPayload())
    });

    const text = await res.text();
    let data = {};
    try { data = JSON.parse(text); } catch (_) {}

    const checkoutUrl = data.checkout_url || data.url || data.checkoutUrl;

    if (!res.ok) throw new Error(text || "Erreur webhook n8n");

    if (checkoutUrl) {
      window.location.href = checkoutUrl;
      return;
    }

    hideLoading();
    showAlert("Le formulaire a été envoyé, mais n8n n’a pas renvoyé d’URL Stripe. Il faut configurer le webhook pour répondre avec checkout_url.");
  } catch (err) {
    hideLoading();
    showAlert("Impossible d’envoyer le formulaire pour le moment. Vérifie le webhook n8n et le CORS.");
    console.error(err);
  }
}

function showAlert(msg) {
  alertMessage.textContent = msg;
  alertBox.classList.remove("hidden");
}

function hideAlert() {
  alertBox.classList.add("hidden");
}

function showLoading() {
  const div = document.createElement("div");
  div.className = "loading";
  div.id = "loadingOverlay";
  div.innerHTML = `<div class="loading-card">
    <div class="spinner"></div>
    <h2>Redirection vers le paiement...</h2>
    <p>Nous sécurisons ta demande avant de lancer la préparation.</p>
  </div>`;
  document.body.appendChild(div);
}

function hideLoading() {
  document.getElementById("loadingOverlay")?.remove();
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, m => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;" }[m]));
}
function escapeAttr(str) { return escapeHtml(str).replace(/"/g, "&quot;"); }

nextBtn.addEventListener("click", next);
prevBtn.addEventListener("click", prev);

render();
